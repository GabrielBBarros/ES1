IDE: Eclipse
openjdk 17.0.2 2022-01-18 LTS

Testar projeto usando o arquivo Restaurante.java, abrir com o eclipse na pasta RESolve

Obs: Todos os diagramas de colaboração estão nomeados, porém alguns aparecem apenas quando além de clicados aparecem no structure no campo superior esquerdo

