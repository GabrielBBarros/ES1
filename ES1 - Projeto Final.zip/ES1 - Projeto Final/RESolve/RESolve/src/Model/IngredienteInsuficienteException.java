package Model;

public class IngredienteInsuficienteException extends Exception {
    public IngredienteInsuficienteException(String message) {
        super(message);
    }
}

