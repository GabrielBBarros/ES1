package Model;

public class ItemEspecialInsuficienteException extends Exception{
	public ItemEspecialInsuficienteException(String message) {
        super(message);
    }
}
